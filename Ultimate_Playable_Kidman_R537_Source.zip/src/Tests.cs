using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using JimJAmes.UPK;

class Fixture {
 public string Root,Game,Package;public Specification Spec;public byte[] Before,After;
 public Fixture(string root) {
  Root=root;Directory.CreateDirectory(root);File.WriteAllText(Path.Combine(root,".fixture"),"Installer test fixture");Game=Path.Combine(root,"game");Package=Path.Combine(root,"package");Directory.CreateDirectory(Game);Directory.CreateDirectory(Package);Exe(Game);
  Spec=new Specification{release="R537",copies=new List<CopyItem>(),patches=new List<PatchItem>()};
  AddCopy("base/a.dat",111,4096,true);AddCopy("base/new.dat",55,2048,false);AddCopy("dinput8.dll",34,128,true);
  Before=Enumerable.Range(0,131072).Select(i=>(byte)(i%251)).ToArray();byte[] tail=Enumerable.Repeat((byte)67,20000).ToArray();After=Before.Concat(tail).ToArray();byte[] x=BitConverter.GetBytes((long)After.Length),y=new byte[]{1,9,3,7};Buffer.BlockCopy(x,0,After,24,8);Buffer.BlockCopy(y,0,After,64000,4);
  string path="virtualtextures/test.pages",payload="patch.dat";Write(Game,path,Before);Write(Package,payload,tail);
  Spec.patches.Add(new PatchItem{path=path,payload=payload,before_size=Before.Length,after_size=After.Length,before_sha256=HashBytes(Before),after_sha256=HashBytes(After),payload_sha256=Files.Hash(Path.Combine(Package,payload)),writes=new List<WriteItem>{new WriteItem{offset=24,before=Files.Hex(Before.Skip(24).Take(8).ToArray()),after=Files.Hex(x)},new WriteItem{offset=64000,before=Files.Hex(Before.Skip(64000).Take(4).ToArray()),after=Files.Hex(y)}}});
 }
 public static string HashBytes(byte[] data){using(var h=System.Security.Cryptography.SHA256.Create())return Files.Hex(h.ComputeHash(data));}
 public static void Write(string root,string path,byte[] data){string p=Files.Under(root,path);Directory.CreateDirectory(Path.GetDirectoryName(p));File.WriteAllBytes(p,data);}
 void AddCopy(string path,int value,int size,bool existed) {
  byte[] data=Enumerable.Repeat((byte)value,size).ToArray();Write(Package,path,data);Spec.copies.Add(new CopyItem{path=path,payload=path,size=size,sha256=HashBytes(data)});
  if(existed)Write(Game,path,Enumerable.Repeat((byte)(value+1),size+13).ToArray());
 }
 public static void Exe(string root) {
  byte[] pe=new byte[1024];using(var m=new MemoryStream(pe))using(var w=new BinaryWriter(m)){w.Write((ushort)0x5a4d);m.Position=0x3c;w.Write((uint)128);m.Position=128;w.Write((uint)0x4550);w.Write((ushort)0x8664);m.Position=136;w.Write((uint)0x5566c3d1);m.Position=152;w.Write((ushort)0x20b);m.Position=208;w.Write((uint)0x9f3d000);}File.WriteAllBytes(Path.Combine(root,"EvilWithin.exe"),pe);
 }
 public Engine Engine(Func<bool> cancel=null,Action<string> report=null){return new Engine(Package,Game,Spec,report??(s=>{}),cancel??(()=>false),()=>{});}
 public void Original() {
  foreach(var c in Spec.copies){string p=Files.Under(Game,c.path);if(c.path=="base/new.dat"){Check(!File.Exists(p),"new file removed");continue;}byte[] old=Enumerable.Repeat((byte)(File.ReadAllBytes(Files.Under(Package,c.payload))[0]+1),(int)c.size+13).ToArray();Check(File.ReadAllBytes(p).SequenceEqual(old),"original "+c.path);}
  Check(File.ReadAllBytes(Files.Under(Game,Spec.patches[0].path)).SequenceEqual(Before),"original texture");
 }
 public void Installed(){foreach(var c in Spec.copies)Check(Files.Hash(Files.Under(Game,c.path))==c.sha256,"installed "+c.path);Check(Files.Hash(Files.Under(Game,Spec.patches[0].path))==Spec.patches[0].after_sha256,"installed texture");}
 public static void Check(bool value,string label){if(!value)throw new Exception("CHECK FAILED: "+label);}
}
class Tests {
 static string Root;static List<string> Results=new List<string>();
 static Fixture New(string name){return new Fixture(Path.Combine(Root,"fixture_"+name));}
 static void ExpectFailure(Action action,string label){bool failed=false;try{action();}catch(Exception){failed=true;}Fixture.Check(failed,label);}
 static void Run(string name,Action action){Engine.Fault=null;action();Results.Add("PASS "+name);Console.WriteLine(Results.Last());Engine.Fault=null;}
 static Fixture UpgradeFixture(string name) {
  var f=New(name);f.Engine().Install();
  foreach(string path in Directory.GetFiles(Files.Under(f.Game,".JimJAmes_UPK/transactions"),"journal.json",SearchOption.AllDirectories)){var j=Files.Read<Journal>(path);j.release="R485";Files.Save(path,j);}
  var old=f.Spec.patches[0];byte[] tail=Enumerable.Repeat((byte)91,777).ToArray();byte[] current=f.After.Concat(tail).ToArray();Buffer.BlockCopy(BitConverter.GetBytes((long)current.Length),0,current,24,8);
  Fixture.Write(f.Package,"patch509.dat",current.Skip((int)old.before_size).ToArray());Fixture.Write(f.Package,"upgrade485.dat",tail);
  var primary=new PatchItem{path=old.path,payload="patch509.dat",before_size=old.before_size,after_size=current.Length,before_sha256=old.before_sha256,after_sha256=Fixture.HashBytes(current),payload_sha256=Files.Hash(Files.Under(f.Package,"patch509.dat")),writes=old.writes.Select(w=>new WriteItem{offset=w.offset,before=w.before,after=Files.Hex(current.Skip((int)w.offset).Take(Files.Bytes(w.before).Length).ToArray())}).ToList()};
  var upgrade=new PatchItem{path=old.path,payload="upgrade485.dat",before_size=old.after_size,after_size=current.Length,before_sha256=old.after_sha256,after_sha256=primary.after_sha256,payload_sha256=Files.Hash(Files.Under(f.Package,"upgrade485.dat")),writes=new List<WriteItem>{new WriteItem{offset=24,before=Files.Hex(f.After.Skip(24).Take(8).ToArray()),after=Files.Hex(current.Skip(24).Take(8).ToArray())}}};
  f.Spec.legacy_patches=new List<PatchItem>{old};f.Spec.upgrade_patches=new List<PatchItem>{upgrade};f.Spec.patches=new List<PatchItem>{primary};f.After=current;return f;
 }
 static void Main(string[] args) {
  try {
   Root=Path.GetFullPath(args[0]);Directory.CreateDirectory(Root);
   Run("install, exact output, idempotence and uninstall",()=>{var f=New("normal");f.Engine().Install();f.Installed();int journals=Directory.GetDirectories(Files.Under(f.Game,".JimJAmes_UPK/transactions")).Length;f.Engine().Install();f.Installed();Fixture.Check(Directory.GetDirectories(Files.Under(f.Game,".JimJAmes_UPK/transactions")).Length==journals,"idempotence");f.Engine().Uninstall();f.Original();});
   Run("wrong original rejected before changes",()=>{var f=New("wrong_base");byte[] bad=f.Before.ToArray();bad[7]^=12;Fixture.Write(f.Game,f.Spec.patches[0].path,bad);ExpectFailure(()=>f.Engine().Install(),"wrong base rejected");Fixture.Check(!Directory.Exists(Files.Under(f.Game,".JimJAmes_UPK/transactions")),"no transaction for unsupported base");});
   Run("corrupt full payload rejected before game changes",()=>{var f=New("bad_payload");var c=f.Spec.copies[0];byte[] bad=File.ReadAllBytes(Files.Under(f.Package,c.payload));bad[1]^=55;Fixture.Write(f.Package,c.payload,bad);ExpectFailure(()=>f.Engine().Install(),"bad payload rejected");bad[1]^=55;Fixture.Write(f.Package,c.payload,bad);f.Original();});
   Run("corrupt patch rejected before changes",()=>{var f=New("bad_patch");string p=Files.Under(f.Package,f.Spec.patches[0].payload);byte[] data=File.ReadAllBytes(p);data[0]^=1;File.WriteAllBytes(p,data);ExpectFailure(()=>f.Engine().Install(),"patch checksum");f.Original();});
   Run("cancel during staging preserves game",()=>{var f=New("cancel");bool cancel=false;ExpectFailure(()=>f.Engine(()=>cancel,m=>{if(m.StartsWith("Preparing"))cancel=true;}).Install(),"cancelled");f.Original();});
   Run("failure after backup restores missing target",()=>{var f=New("backup_failure");Engine.Fault=p=>{if(p=="copy_backed_up")throw new IOException("injected");};ExpectFailure(()=>f.Engine().Install(),"fault");Engine.Fault=null;f.Original();});
   Run("failure after append rolls back copies and patch",()=>{var f=New("append_failure");Engine.Fault=p=>{if(p=="patch_append")throw new IOException("injected");};ExpectFailure(()=>f.Engine().Install(),"fault");Engine.Fault=null;f.Original();});
   Run("interrupted-install journal recovers partial patch and moved file",()=>{
    var f=New("recovery");var c=f.Spec.copies[0];var p=f.Spec.patches[0];string tx=".JimJAmes_UPK/transactions/crash",target=Files.Under(f.Game,c.path),before=Files.Hash(target),backup=Files.Under(f.Game,tx+"/backup/"+c.path);Directory.CreateDirectory(Path.GetDirectoryName(backup));File.Move(target,backup);File.Copy(Files.Under(f.Package,c.payload),target);
    var ops=new List<Operation>{new Operation{path=c.path,kind="copy",phase="done",existed=true,before_sha256=before,after_sha256=c.sha256},new Operation{path=p.path,kind="patch",phase="started",existed=true,before_sha256=p.before_sha256,after_sha256=p.after_sha256,before_size=p.before_size,writes=p.writes}};
    Files.Save(Files.Under(f.Game,tx+"/journal.json"),new Journal{release="R537",state="installing",operations=ops});
    using(var file=new FileStream(Files.Under(f.Game,p.path),FileMode.Open,FileAccess.ReadWrite)){file.Position=file.Length;file.Write(new byte[17],0,17);file.Position=p.writes[0].offset;byte[] bytes=Files.Bytes(p.writes[0].after);file.Write(bytes,0,3);}
    f.Engine().Recover();f.Original();
   });
   Run("restore refuses later user edits",()=>{var f=New("foreign_edit");f.Engine().Install();Fixture.Write(f.Game,f.Spec.copies[0].path,new byte[]{1,2,3});ExpectFailure(()=>f.Engine().Uninstall(),"preserve edit");Fixture.Check(File.ReadAllBytes(Files.Under(f.Game,f.Spec.copies[0].path)).SequenceEqual(new byte[]{1,2,3}),"edit preserved");Fixture.Check(Files.Hash(Files.Under(f.Game,f.Spec.patches[0].path))==f.Spec.patches[0].after_sha256,"no partial restore");});
   Run("path traversal and unsupported executable rejected",()=>{var f=New("unsafe");f.Spec.copies[0].path="../outside";ExpectFailure(()=>f.Engine(),"traversal");var g=New("bad_exe");File.WriteAllBytes(Path.Combine(g.Game,"EvilWithin.exe"),new byte[1024]);ExpectFailure(()=>g.Engine().Install(),"unsupported exe");g.Original();});
   Run("R461 journal upgrade and two-step restoration",()=>{
    var f=New("legacy_upgrade");f.Engine().Install();
    foreach(string p in Directory.GetFiles(Files.Under(f.Game,".JimJAmes_UPK/transactions"),"journal.json",SearchOption.AllDirectories)){var j=Files.Read<Journal>(p);j.release="R461";Files.Save(p,j);string dir=Path.GetDirectoryName(p);Directory.Move(dir,Path.Combine(Path.GetDirectoryName(dir),DateTime.UtcNow.AddMinutes(2).ToString("yyyyMMdd_HHmmss")+"_ffffffffffffffffffffffffffffffff"));}
    f.Spec.legacy_copies=f.Spec.copies.Select(c=>new CopyItem{path=c.path,sha256=c.sha256}).ToList();
    var copy=f.Spec.copies[0];byte[] bytes=File.ReadAllBytes(Files.Under(f.Package,copy.payload));bytes[0]^=61;Fixture.Write(f.Package,copy.payload,bytes);copy.sha256=Files.Hash(Files.Under(f.Package,copy.payload));
    f.Engine().Install();f.Installed();f.Engine().Uninstall();Fixture.Check(Files.Hash(Files.Under(f.Game,copy.path))==f.Spec.legacy_copies[0].sha256,"restore previous release");f.Engine().Uninstall();bytes[0]^=61;Fixture.Write(f.Package,copy.payload,bytes);f.Original();
   });
   Run("R464 journal upgrade and two-step restoration",()=>{
    var f=New("legacy_upgrade464");f.Engine().Install();
    foreach(string p in Directory.GetFiles(Files.Under(f.Game,".JimJAmes_UPK/transactions"),"journal.json",SearchOption.AllDirectories)){var j=Files.Read<Journal>(p);j.release="R464";Files.Save(p,j);string dir=Path.GetDirectoryName(p);Directory.Move(dir,Path.Combine(Path.GetDirectoryName(dir),DateTime.UtcNow.AddMinutes(2).ToString("yyyyMMdd_HHmmss")+"_ffffffffffffffffffffffffffffffff"));}
    f.Spec.legacy_copies=f.Spec.copies.Select(c=>new CopyItem{path=c.path,sha256=c.sha256}).ToList();
    var copy=f.Spec.copies[0];byte[] bytes=File.ReadAllBytes(Files.Under(f.Package,copy.payload));bytes[0]^=61;Fixture.Write(f.Package,copy.payload,bytes);copy.sha256=Files.Hash(Files.Under(f.Package,copy.payload));
    f.Engine().Install();f.Installed();f.Engine().Uninstall();Fixture.Check(Files.Hash(Files.Under(f.Game,copy.path))==f.Spec.legacy_copies[0].sha256,"restore previous release");f.Engine().Uninstall();bytes[0]^=61;Fixture.Write(f.Package,copy.payload,bytes);f.Original();
   });
   Run("R466 journal upgrade and two-step restoration",()=>{
    var f=New("legacy_upgrade466");f.Engine().Install();
    foreach(string p in Directory.GetFiles(Files.Under(f.Game,".JimJAmes_UPK/transactions"),"journal.json",SearchOption.AllDirectories)){var j=Files.Read<Journal>(p);j.release="R466";Files.Save(p,j);string dir=Path.GetDirectoryName(p);Directory.Move(dir,Path.Combine(Path.GetDirectoryName(dir),DateTime.UtcNow.AddMinutes(2).ToString("yyyyMMdd_HHmmss")+"_ffffffffffffffffffffffffffffffff"));}
    f.Spec.legacy_copies=f.Spec.copies.Select(c=>new CopyItem{path=c.path,sha256=c.sha256}).ToList();
    var copy=f.Spec.copies[0];byte[] bytes=File.ReadAllBytes(Files.Under(f.Package,copy.payload));bytes[0]^=61;Fixture.Write(f.Package,copy.payload,bytes);copy.sha256=Files.Hash(Files.Under(f.Package,copy.payload));
    f.Engine().Install();f.Installed();f.Engine().Uninstall();Fixture.Check(Files.Hash(Files.Under(f.Game,copy.path))==f.Spec.legacy_copies[0].sha256,"restore previous release");f.Engine().Uninstall();bytes[0]^=61;Fixture.Write(f.Package,copy.payload,bytes);f.Original();
   });
   Run("R472 journal upgrade and two-step restoration",()=>{
    var f=New("legacy_upgrade472");f.Engine().Install();
    foreach(string p in Directory.GetFiles(Files.Under(f.Game,".JimJAmes_UPK/transactions"),"journal.json",SearchOption.AllDirectories)){var j=Files.Read<Journal>(p);j.release="R472";Files.Save(p,j);string dir=Path.GetDirectoryName(p);Directory.Move(dir,Path.Combine(Path.GetDirectoryName(dir),DateTime.UtcNow.AddMinutes(2).ToString("yyyyMMdd_HHmmss")+"_ffffffffffffffffffffffffffffffff"));}
    f.Spec.legacy_copies=f.Spec.copies.Select(c=>new CopyItem{path=c.path,sha256=c.sha256}).ToList();
    var copy=f.Spec.copies[0];byte[] bytes=File.ReadAllBytes(Files.Under(f.Package,copy.payload));bytes[0]^=61;Fixture.Write(f.Package,copy.payload,bytes);copy.sha256=Files.Hash(Files.Under(f.Package,copy.payload));
    f.Engine().Install();f.Installed();f.Engine().Uninstall();Fixture.Check(Files.Hash(Files.Under(f.Game,copy.path))==f.Spec.legacy_copies[0].sha256,"restore previous release");f.Engine().Uninstall();bytes[0]^=61;Fixture.Write(f.Package,copy.payload,bytes);f.Original();
   });
   Run("R478 journal upgrade and two-step restoration",()=>{
    var f=New("legacy_upgrade478");f.Engine().Install();
    foreach(string p in Directory.GetFiles(Files.Under(f.Game,".JimJAmes_UPK/transactions"),"journal.json",SearchOption.AllDirectories)){var j=Files.Read<Journal>(p);j.release="R478";Files.Save(p,j);string dir=Path.GetDirectoryName(p);Directory.Move(dir,Path.Combine(Path.GetDirectoryName(dir),DateTime.UtcNow.AddMinutes(2).ToString("yyyyMMdd_HHmmss")+"_ffffffffffffffffffffffffffffffff"));}
    f.Spec.legacy_copies=f.Spec.copies.Select(c=>new CopyItem{path=c.path,sha256=c.sha256}).ToList();
    var copy=f.Spec.copies[0];byte[] bytes=File.ReadAllBytes(Files.Under(f.Package,copy.payload));bytes[0]^=61;Fixture.Write(f.Package,copy.payload,bytes);copy.sha256=Files.Hash(Files.Under(f.Package,copy.payload));
    f.Engine().Install();f.Installed();f.Engine().Uninstall();Fixture.Check(Files.Hash(Files.Under(f.Game,copy.path))==f.Spec.legacy_copies[0].sha256,"restore previous release");f.Engine().Uninstall();bytes[0]^=61;Fixture.Write(f.Package,copy.payload,bytes);f.Original();
   });
   Run("R483 journal upgrade and two-step restoration",()=>{
    var f=New("legacy_upgrade483");f.Engine().Install();
    foreach(string p in Directory.GetFiles(Files.Under(f.Game,".JimJAmes_UPK/transactions"),"journal.json",SearchOption.AllDirectories)){var j=Files.Read<Journal>(p);j.release="R483";Files.Save(p,j);string dir=Path.GetDirectoryName(p);Directory.Move(dir,Path.Combine(Path.GetDirectoryName(dir),DateTime.UtcNow.AddMinutes(2).ToString("yyyyMMdd_HHmmss")+"_ffffffffffffffffffffffffffffffff"));}
    f.Spec.legacy_copies=f.Spec.copies.Select(c=>new CopyItem{path=c.path,sha256=c.sha256}).ToList();
    var copy=f.Spec.copies[0];byte[] bytes=File.ReadAllBytes(Files.Under(f.Package,copy.payload));bytes[0]^=61;Fixture.Write(f.Package,copy.payload,bytes);copy.sha256=Files.Hash(Files.Under(f.Package,copy.payload));
    f.Engine().Install();f.Installed();f.Engine().Uninstall();Fixture.Check(Files.Hash(Files.Under(f.Game,copy.path))==f.Spec.legacy_copies[0].sha256,"restore previous release");f.Engine().Uninstall();bytes[0]^=61;Fixture.Write(f.Package,copy.payload,bytes);f.Original();
   });
   Run("R485 journal upgrade and two-step restoration",()=>{
    var f=New("legacy_upgrade485");f.Engine().Install();
    foreach(string p in Directory.GetFiles(Files.Under(f.Game,".JimJAmes_UPK/transactions"),"journal.json",SearchOption.AllDirectories)){var j=Files.Read<Journal>(p);j.release="R485";Files.Save(p,j);string dir=Path.GetDirectoryName(p);Directory.Move(dir,Path.Combine(Path.GetDirectoryName(dir),DateTime.UtcNow.AddMinutes(2).ToString("yyyyMMdd_HHmmss")+"_ffffffffffffffffffffffffffffffff"));}
    f.Spec.legacy_copies=f.Spec.copies.Select(c=>new CopyItem{path=c.path,sha256=c.sha256}).ToList();
    var copy=f.Spec.copies[0];byte[] bytes=File.ReadAllBytes(Files.Under(f.Package,copy.payload));bytes[0]^=61;Fixture.Write(f.Package,copy.payload,bytes);copy.sha256=Files.Hash(Files.Under(f.Package,copy.payload));
    f.Engine().Install();f.Installed();f.Engine().Uninstall();Fixture.Check(Files.Hash(Files.Under(f.Game,copy.path))==f.Spec.legacy_copies[0].sha256,"restore previous release");f.Engine().Uninstall();bytes[0]^=61;Fixture.Write(f.Package,copy.payload,bytes);f.Original();
   });
   Run("R509 journal upgrade and two-step restoration",()=>{
    var f=New("legacy_upgrade509");var copy=f.Spec.copies[0];string target=Files.Under(f.Game,copy.path);byte[] original=File.ReadAllBytes(target);f.Engine().Install();byte[] priorInstalled=File.ReadAllBytes(target);string priorHash=Files.Hash(target);
    foreach(string p in Directory.GetFiles(Files.Under(f.Game,".JimJAmes_UPK/transactions"),"journal.json",SearchOption.AllDirectories)){var j=Files.Read<Journal>(p);j.release="R509";Files.Save(p,j);}
    f.Spec.legacy_copies=f.Spec.copies.Select(c=>new CopyItem{path=c.path,sha256=c.sha256}).ToList();byte[] next=File.ReadAllBytes(Files.Under(f.Package,copy.payload));next[0]^=61;Fixture.Write(f.Package,copy.payload,next);copy.sha256=Files.Hash(Files.Under(f.Package,copy.payload));
    f.Engine().Install();Fixture.Check(Files.Hash(target)==copy.sha256,"R537 payload installed");f.Engine().Uninstall();Fixture.Check(File.ReadAllBytes(target).SequenceEqual(priorInstalled)&&Files.Hash(target)==priorHash,"R509 payload restored");
    f.Engine().Uninstall();Fixture.Check(File.ReadAllBytes(target).SequenceEqual(original),"original payload restored");Fixture.Check(File.ReadAllBytes(Files.Under(f.Game,f.Spec.patches[0].path)).SequenceEqual(f.Before),"original atlas restored");
   });
   Run("separate installer and selected content folder",()=>{
    var f=New("separate_content");string tools=Path.Combine(f.Root,"downloaded_installer"),content=Path.Combine(f.Root,"extracted_nexus_content");Directory.CreateDirectory(tools);Directory.Move(f.Package,content);f.Package=content;
    f.Engine().Install();f.Installed();Directory.Move(content,content+"_removed");
    var restore=new Engine(tools,f.Game,f.Spec,s=>{},()=>false,()=>{});restore.Uninstall();Directory.Move(content+"_removed",content);f.Original();
   });
   Run("R485 atlas upgrade and exact two-step restoration",()=>{
    var f=UpgradeFixture("atlas_upgrade485");f.Engine().Install();f.Installed();f.Engine().Uninstall();Fixture.Check(Files.Hash(Files.Under(f.Game,f.Spec.patches[0].path))==f.Spec.legacy_patches[0].after_sha256,"restored R485 atlas");f.Engine().Uninstall();f.Original();
   });
   Run("corrupt atlas upgrade rejected before changes",()=>{
    var f=UpgradeFixture("atlas_upgrade_corrupt");string path=Files.Under(f.Package,f.Spec.upgrade_patches[0].payload);File.WriteAllBytes(path,new byte[777]);ExpectFailure(()=>f.Engine().Install(),"corrupt upgrade rejected");Fixture.Check(Files.Hash(Files.Under(f.Game,f.Spec.patches[0].path))==f.Spec.legacy_patches[0].after_sha256,"old atlas preserved");f.Engine().Uninstall();f.Original();
   });
   if(args.Length>1)Run("real native atlas: exact install and restore with64bit offsets",()=>{
    string package=Path.GetFullPath(args[1]),full=Path.GetFullPath(args[2]);var spec=Files.Read<Specification>(Path.Combine(package,"PAYLOAD_MANIFEST.json"));var p=spec.patches.OrderByDescending(x=>x.before_size).First();string dir=Path.Combine(Root,"fixture_large");Directory.CreateDirectory(dir);File.WriteAllText(Path.Combine(dir,".fixture"),"large native test");string game=Path.Combine(dir,"game");Directory.CreateDirectory(game);Fixture.Exe(game);string target=Files.Under(game,p.path);Directory.CreateDirectory(Path.GetDirectoryName(target));File.Copy(Files.Under(full,p.path),target);
    using(var file=new FileStream(target,FileMode.Open,FileAccess.ReadWrite)){foreach(var w in p.writes){file.Position=w.offset;byte[] b=Files.Bytes(w.before);file.Write(b,0,b.Length);}file.SetLength(p.before_size);file.Flush(true);}
    Fixture.Check(Files.Hash(target)==p.before_sha256,"reconstructed original");var only=new Specification{release="R537",copies=new List<CopyItem>(),patches=new List<PatchItem>{p}};var engine=new Engine(package,game,only,Console.WriteLine,()=>false,()=>{});engine.Install();Fixture.Check(Files.Hash(target)==p.after_sha256,"real atlas target");engine.Uninstall();Fixture.Check(Files.Hash(target)==p.before_sha256,"real atlas restoration");File.Delete(target);
   });
   File.WriteAllLines(Path.Combine(Root,"test_results.txt"),Results.Concat(new[]{"ALL TESTS PASSED"}));Console.WriteLine("ALL TESTS PASSED");
  } catch(Exception e){Console.WriteLine(e);Environment.ExitCode=1;}
 }
}
