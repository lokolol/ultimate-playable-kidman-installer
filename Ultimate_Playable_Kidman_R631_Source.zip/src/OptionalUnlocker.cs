using System;
using System.Collections.Generic;
using JimJAmes.UPK;

// Separate transaction namespace allows local activation without reinstalling a campaign payload.
class OptionalUnlocker {
 public static int Main(string[] args) {
  try {
   if(args.Length!=3 || (args[0]!="install" && args[0]!="restore"))throw new ArgumentException("Usage: OptionalUnlocker.exe install|restore GAME_FOLDER COMPONENT_FOLDER");
   var spec=new Specification{release="R631",copies=new List<CopyItem>(),patches=new List<PatchItem>()};
   var engine=new Engine(args[2],args[1],spec,Console.WriteLine,()=>false,Files.ClosedGame,args[0]=="install",args[2],true);
   string result=args[0]=="install"?engine.Install():engine.Uninstall();
   Console.WriteLine(result);return 0;
  } catch(Exception e){Console.Error.WriteLine(e.Message);return 1;}
 }
}
