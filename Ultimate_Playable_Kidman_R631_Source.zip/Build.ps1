param(
    [string]$PayloadManifest = '',
    [switch]$SkipTests
)
$ErrorActionPreference = 'Stop'
function FileSha256([string]$Path) {
    $stream = [IO.File]::OpenRead($Path)
    $hash = [Security.Cryptography.SHA256]::Create()
    try { return [BitConverter]::ToString($hash.ComputeHash($stream)).Replace('-', '').ToLowerInvariant() }
    finally { $hash.Dispose(); $stream.Dispose() }
}
$projectRoot = $PSScriptRoot
$release = Get-Content -LiteralPath (Join-Path $projectRoot 'release.json') -Raw | ConvertFrom-Json
if ($PayloadManifest) {
    if ((FileSha256 $PayloadManifest) -ne $release.manifest_sha256) {
        throw "The supplied manifest does not match the official $($release.release) release."
    }
}
$compiler = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
if (-not (Test-Path -LiteralPath $compiler)) { throw 'The Windows x64 .NET Framework C# compiler was not found.' }
$output = Join-Path $projectRoot 'build'
New-Item -ItemType Directory -Path $output -Force | Out-Null
$launcher = [IO.File]::ReadAllText((Join-Path $projectRoot 'src\Launcher.cs'))
if ([regex]::Matches($launcher, '__PAYLOAD_MANIFEST_SHA256__').Count -ne 1) { throw 'Unexpected launcher template.' }
$generated = Join-Path $output 'Launcher.Generated.cs'
[IO.File]::WriteAllText($generated, $launcher.Replace('__PAYLOAD_MANIFEST_SHA256__', $release.manifest_sha256))
$engine = Join-Path $projectRoot 'src\Engine.cs'
$installer = Join-Path $output 'Install.exe'
& $compiler /nologo /target:winexe /platform:x64 /optimize+ /warnaserror+ /r:System.Runtime.Serialization.dll /r:System.Windows.Forms.dll /r:System.Drawing.dll "/out:$installer" $engine $generated
if ($LASTEXITCODE -ne 0) { throw 'Installer compilation failed.' }
$optionalHelper = Join-Path $output 'OptionalUnlocker.exe'
& $compiler /nologo /target:exe /platform:x64 /optimize+ /warnaserror+ /r:System.Runtime.Serialization.dll "/out:$optionalHelper" $engine (Join-Path $projectRoot 'src\OptionalUnlocker.cs')
if ($LASTEXITCODE -ne 0) { throw 'Optional helper compilation failed.' }
if (-not $SkipTests) {
    $tests = Join-Path $output 'Tests.exe'
    & $compiler /nologo /target:exe /platform:x64 /optimize+ /warnaserror+ /define:SELF_TEST /r:System.Runtime.Serialization.dll "/out:$tests" $engine (Join-Path $projectRoot 'src\Tests.cs')
    if ($LASTEXITCODE -ne 0) { throw 'Test compilation failed.' }
    $fixtureRoot = Join-Path $env:TEMP ('UPK_' + [guid]::NewGuid().ToString('N'))
    & $tests $fixtureRoot
    if ($LASTEXITCODE -ne 0) { throw 'Installer tests failed.' }
    Copy-Item -LiteralPath (Join-Path $fixtureRoot 'test_results.txt') -Destination (Join-Path $output 'test_results.txt')
    $resolvedFixture = (Resolve-Path -LiteralPath $fixtureRoot).Path
    $resolvedTemp = (Resolve-Path -LiteralPath $env:TEMP).Path.TrimEnd('\') + '\'
    if (-not $resolvedFixture.StartsWith($resolvedTemp, [StringComparison]::OrdinalIgnoreCase)) { throw 'Unexpected fixture cleanup path.' }
    Remove-Item -LiteralPath $resolvedFixture -Recurse -Force
    if (Test-Path -LiteralPath (Join-Path $projectRoot 'Optional\FightingChance\steam_api64.dll')) {
        $optionalTests = Join-Path $output 'UnlockerTests.exe'
        & $compiler /nologo /target:exe /platform:x64 /optimize+ /warnaserror+ /define:SELF_TEST /main:UnlockerTests /r:System.Runtime.Serialization.dll "/out:$optionalTests" $engine (Join-Path $projectRoot 'src\Tests.cs') (Join-Path $projectRoot 'src\UnlockerTests.cs')
        if ($LASTEXITCODE -ne 0) { throw 'Optional tests compilation failed.' }
        $optionalFixture = Join-Path $env:TEMP ('UPK_Optional_' + [guid]::NewGuid().ToString('N'))
        $optionalResults = & $optionalTests $optionalFixture $projectRoot
        $optionalResults | Set-Content -LiteralPath (Join-Path $output 'optional_test_results.txt')
        if ($LASTEXITCODE -ne 0) { throw 'Optional component tests failed.' }
        $resolvedOptional = (Resolve-Path -LiteralPath $optionalFixture).Path
        if (-not $resolvedOptional.StartsWith($resolvedTemp, [StringComparison]::OrdinalIgnoreCase)) { throw 'Unexpected optional fixture cleanup path.' }
        Remove-Item -LiteralPath $resolvedOptional -Recurse -Force
    }
}
$optionalSource = Join-Path $projectRoot 'Optional'
if (Test-Path -LiteralPath $optionalSource) { Copy-Item -LiteralPath $optionalSource -Destination $output -Recurse -Force }
Write-Output "Built: $installer"
Write-Output "SHA256: $(FileSha256 $installer)"
