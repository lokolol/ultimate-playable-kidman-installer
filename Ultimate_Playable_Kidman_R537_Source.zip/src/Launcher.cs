using System;
using System.IO;
using System.Linq;
using System.Drawing;
using System.ComponentModel;
using System.Windows.Forms;
using Microsoft.Win32;

namespace JimJAmes.UPK {
public class InstallerForm:Form {
 const string PinnedManifest="__PAYLOAD_MANIFEST_SHA256__";
 readonly string package=AppDomain.CurrentDomain.BaseDirectory;
 readonly Specification specification;
 TextBox folder=new TextBox();Label status=new Label();ProgressBar progress=new ProgressBar();Button install=new Button(),restore=new Button(),browse=new Button(),cancel=new Button();
 BackgroundWorker worker=new BackgroundWorker();volatile bool cancelling=false;
 public InstallerForm() {
  string manifest=Path.Combine(package,"PAYLOAD_MANIFEST.json");Files.Require(File.Exists(manifest) && Files.Hash(manifest)==PinnedManifest,"Installer manifest is missing or damaged. Keep Install.exe beside the matching PAYLOAD_MANIFEST.json from the GitHub download.");specification=Files.Read<Specification>(manifest);
  Text="Ultimate Playable Kidman R537 - JimJAmes";ClientSize=new Size(660,300);FormBorderStyle=FormBorderStyle.FixedDialog;MaximizeBox=false;StartPosition=FormStartPosition.CenterScreen;Font=new Font("Segoe UI",10);
  Controls.Add(new Label{Text="Ultimate Playable Kidman R537",Font=new Font("Segoe UI",16,FontStyle.Bold),Location=new Point(20,18),AutoSize=true});
  Controls.Add(new Label{Text="By JimJAmes | Close the game before installing.",Location=new Point(22,58),AutoSize=true});
  Controls.Add(new Label{Text="Game folder (contains EvilWithin.exe):",Location=new Point(22,93),AutoSize=true});
  folder.SetBounds(22,120,480,28);folder.Text=FindGame();Controls.Add(folder);browse.Text="Browse...";browse.SetBounds(514,119,120,30);Controls.Add(browse);
  Controls.Add(new Label{Text="Previous files are preserved. Screen/resolution fixes are excluded.",Location=new Point(22,160),AutoSize=true});
  install.Text="Install R537";install.SetBounds(22,200,145,35);Controls.Add(install);restore.Text="Restore previous files";restore.SetBounds(179,200,190,35);Controls.Add(restore);cancel.Text="Close";cancel.SetBounds(514,200,120,35);Controls.Add(cancel);
  status.Text="Ready";status.SetBounds(22,245,610,24);status.AutoEllipsis=true;Controls.Add(status);progress.SetBounds(22,277,612,8);Controls.Add(progress);
  browse.Click+=delegate {using(var d=new FolderBrowserDialog()){d.Description="Select the folder containing EvilWithin.exe";if(Directory.Exists(folder.Text))d.SelectedPath=folder.Text;if(d.ShowDialog()==DialogResult.OK)folder.Text=d.SelectedPath;}};
  install.Click+=delegate{Run(false);};restore.Click+=delegate{Run(true);};cancel.Click+=delegate{if(worker.IsBusy){cancelling=true;status.Text="Cancelling safely; restoring previous files...";cancel.Enabled=false;}else Close();};
  worker.WorkerReportsProgress=true;worker.ProgressChanged+=delegate(object s,ProgressChangedEventArgs e){status.Text=(string)e.UserState;};
  worker.DoWork+=delegate(object s,DoWorkEventArgs e){string[] args=(string[])e.Argument;var engine=new Engine(args[2],args[0],specification,m=>worker.ReportProgress(0,m),()=>cancelling,Files.ClosedGame);e.Result=args[1]=="restore"?engine.Uninstall():engine.Install();};
  worker.RunWorkerCompleted+=delegate(object s,RunWorkerCompletedEventArgs e){install.Enabled=restore.Enabled=browse.Enabled=folder.Enabled=cancel.Enabled=true;cancel.Text="Close";progress.Style=ProgressBarStyle.Blocks;if(e.Error!=null){status.Text="Stopped - see message";string message=e.Error.Message;if(e.Error is UnauthorizedAccessException)message+="\nIf this game folder needs administrator access, close this installer and use Run as administrator.";MessageBox.Show(this,message,Text,MessageBoxButtons.OK,MessageBoxIcon.Warning);}else{status.Text=(string)e.Result;MessageBox.Show(this,(string)e.Result,Text,MessageBoxButtons.OK,MessageBoxIcon.Information);}};
  FormClosing+=delegate(object s,FormClosingEventArgs e){if(worker.IsBusy){e.Cancel=true;MessageBox.Show(this,"Use Cancel and wait for restoration before closing.",Text);}};
 }
 void Run(bool undo) {
  string game=folder.Text.Trim().Trim('"');
  try{Files.SupportedExe(game);Files.ClosedGame();}catch(Exception error){MessageBox.Show(this,error.Message,Text,MessageBoxButtons.OK,MessageBoxIcon.Warning);return;}
  if(undo && MessageBox.Show(this,"Restore the files that existed before the latest installer run?",Text,MessageBoxButtons.YesNo,MessageBoxIcon.Question)!=DialogResult.Yes)return;
  string content=package;
  if(!undo) {
   if(!HasContent(content)) {
    using(var d=new FolderBrowserDialog()) {
     d.Description="Select the extracted Nexus content folder (the folder containing Payload)";
     if(d.ShowDialog()!=DialogResult.OK)return;
     content=Path.GetFullPath(d.SelectedPath);
     if(String.Equals(Path.GetFileName(content.TrimEnd(Path.DirectorySeparatorChar)),"Payload",StringComparison.OrdinalIgnoreCase))content=Path.GetDirectoryName(content);
    }
   }
   if(!HasContent(content)){MessageBox.Show(this,"The selected folder does not contain the complete extracted Nexus Payload. Extract the ZIP completely, then select its folder.",Text,MessageBoxButtons.OK,MessageBoxIcon.Warning);return;}
  }
  cancelling=false;install.Enabled=restore.Enabled=browse.Enabled=folder.Enabled=false;cancel.Enabled=true;cancel.Text="Cancel";progress.Style=ProgressBarStyle.Marquee;status.Text="Checking files...";worker.RunWorkerAsync(new string[]{game,undo?"restore":"install",content});
 }
 bool HasContent(string root) {
  try{return specification.copies.All(c=>File.Exists(Files.Under(root,c.payload))) && specification.patches.Concat(specification.upgrade_patches??new System.Collections.Generic.List<PatchItem>()).All(p=>File.Exists(Files.Under(root,p.payload)));}catch{return false;}
 }
 static string FindGame() {
  try {
   using(var k=Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\Steam App 268050")){if(k!=null){string p=k.GetValue("InstallLocation") as string;if(p!=null && File.Exists(Path.Combine(p,"EvilWithin.exe")))return p;}}
   using(var k=Registry.CurrentUser.OpenSubKey(@"Software\Valve\Steam")) {
    if(k==null)return "";string steam=k.GetValue("SteamPath") as string;if(steam==null)return "";var roots=new System.Collections.Generic.List<string>();roots.Add(steam);
    string libraries=Path.Combine(steam,@"steamapps\libraryfolders.vdf");if(File.Exists(libraries))foreach(System.Text.RegularExpressions.Match m in System.Text.RegularExpressions.Regex.Matches(File.ReadAllText(libraries),"\"path\"\\s*\"([^\"]+)\""))roots.Add(m.Groups[1].Value.Replace("\\\\","\\"));
    foreach(string root in roots){string p=Path.Combine(root,@"steamapps\common\TheEvilWithin");if(File.Exists(Path.Combine(p,"EvilWithin.exe")))return p;}
   }
  }catch{}return "";
 }
 [STAThread] public static void Main() {
  Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);
  try{Application.Run(new InstallerForm());}catch(Exception e){MessageBox.Show(e.Message,"Ultimate Playable Kidman R537",MessageBoxButtons.OK,MessageBoxIcon.Error);}
 }
}
}
