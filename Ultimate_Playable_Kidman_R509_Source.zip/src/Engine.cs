using System;
using System.IO;
using System.Text;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.Security.Cryptography;
using System.Diagnostics;

namespace JimJAmes.UPK {
[DataContract] public class CopyItem {
 [DataMember] public string path;
 [DataMember] public string payload;
 [DataMember] public long size;
 [DataMember] public string sha256;
}
[DataContract] public class WriteItem {
 [DataMember] public long offset;
 [DataMember] public string before;
 [DataMember] public string after;
}
[DataContract] public class PatchItem {
 [DataMember] public string path;
 [DataMember] public string payload;
 [DataMember] public long before_size;
 [DataMember] public long after_size;
 [DataMember] public string before_sha256;
 [DataMember] public string after_sha256;
 [DataMember] public string payload_sha256;
 [DataMember] public List<WriteItem> writes;
}
[DataContract] public class Specification {
 [DataMember] public string release;
 [DataMember] public List<CopyItem> copies;
 [DataMember] public List<CopyItem> legacy_copies;
 [DataMember] public List<PatchItem> patches;
 [DataMember] public List<PatchItem> legacy_patches;
 [DataMember] public List<PatchItem> upgrade_patches;
}
[DataContract] public class Operation {
 [DataMember] public string path;
 [DataMember] public string kind;
 [DataMember] public string phase;
 [DataMember] public bool existed;
 [DataMember] public string before_sha256;
 [DataMember] public string after_sha256;
 [DataMember] public long before_size;
 [DataMember] public List<WriteItem> writes;
}
[DataContract] public class Journal {
 [DataMember] public string release;
 [DataMember] public string state;
 [DataMember] public List<Operation> operations;
}
public static class Files {
 public static string Hash(string path) {
  using(var h=SHA256.Create()) using(var f=File.OpenRead(path)) return Hex(h.ComputeHash(f));
 }
 public static string Hex(byte[] data) { return BitConverter.ToString(data).Replace("-", "").ToLowerInvariant(); }
 public static byte[] Bytes(string hex) {
  if(hex==null || hex.Length%2!=0) throw new InvalidDataException("Invalid patch bytes.");
  byte[] b=new byte[hex.Length/2]; for(int i=0;i<b.Length;i++) b[i]=Convert.ToByte(hex.Substring(i*2,2),16); return b;
 }
 public static string Under(string root,string relative) {
  if(String.IsNullOrWhiteSpace(relative) || Path.IsPathRooted(relative) || relative.Contains(":")) throw new InvalidDataException("Invalid relative path.");
  string[] parts=relative.Replace('/', '\\').Split('\\');
  if(parts.Any(p=>p=="" || p=="." || p=="..")) throw new InvalidDataException("Unsafe path.");
  string fullroot=Path.GetFullPath(root).TrimEnd('\\')+"\\";
  string path=Path.GetFullPath(Path.Combine(fullroot,relative));
  if(!path.StartsWith(fullroot,StringComparison.OrdinalIgnoreCase)) throw new InvalidDataException("Path leaves the selected folder.");
  string cur=fullroot.TrimEnd('\\');
  foreach(string p in parts) {
   cur=Path.Combine(cur,p);
   if((File.Exists(cur)||Directory.Exists(cur)) && (File.GetAttributes(cur)&FileAttributes.ReparsePoint)!=0) throw new IOException("Linked/reparse paths are not supported: "+relative);
  }
  return path;
 }
 public static T Read<T>(string path) { using(var f=File.OpenRead(path)) return (T)new DataContractJsonSerializer(typeof(T)).ReadObject(f); }
 public static void Save<T>(string path,T value) {
  Directory.CreateDirectory(Path.GetDirectoryName(path));string temp=path+".new";
  using(var f=new FileStream(temp,FileMode.Create,FileAccess.Write,FileShare.None)) { new DataContractJsonSerializer(typeof(T)).WriteObject(f,value);f.Flush(true); }
  if(File.Exists(path)) File.Replace(temp,path,null);else File.Move(temp,path);
 }
 public static void Require(bool condition,string message) { if(!condition) throw new InvalidDataException(message); }
 public static void ClosedGame() {
  if(Process.GetProcessesByName("evilwithin").Length!=0) throw new IOException("Close The Evil Within before installing or restoring files.");
 }
 public static void SupportedExe(string root) {
  string path=Under(root,"EvilWithin.exe");Require(File.Exists(path),"Select the folder containing EvilWithin.exe.");
  using(var f=File.OpenRead(path)) using(var r=new BinaryReader(f)) {
   Require(f.Length>256 && r.ReadUInt16()==0x5a4d,"Unsupported game executable.");f.Position=0x3c;long pe=r.ReadUInt32();Require(pe>=64 && pe+88<f.Length,"Invalid game executable.");
   f.Position=pe;Require(r.ReadUInt32()==0x4550 && r.ReadUInt16()==0x8664,"The supported Windows x64 Steam build is required.");
   f.Position=pe+8;Require(r.ReadUInt32()==0x5566c3d1,"Different game build. No files were changed.");
   f.Position=pe+24;Require(r.ReadUInt16()==0x20b,"Unsupported executable format.");f.Position=pe+24+56;Require(r.ReadUInt32()==0x9f3d000,"Different game image. No files were changed.");
  }
 }
}
public class Engine {
 readonly string package,game,transactions;
 readonly Specification spec;
 readonly Action<string> report;
 readonly Func<bool> cancelled;
 readonly Action guard;
 readonly Dictionary<string,string> allowed=new Dictionary<string,string>(StringComparer.OrdinalIgnoreCase);
#if SELF_TEST
 public static Action<string> Fault;
#endif
 void FaultAt(string point) {
#if SELF_TEST
  if(Fault!=null) Fault(point);
#endif
 }
 public Engine(string packageRoot,string gameRoot,Specification specification,Action<string> progress,Func<bool> cancellation,Action gameGuard) {
  package=Path.GetFullPath(packageRoot);game=Path.GetFullPath(gameRoot);spec=specification;report=progress;cancelled=cancellation;guard=gameGuard;
  Files.Require(spec.release=="R509" && spec.copies!=null && spec.patches!=null,"Unsupported installer manifest.");
  transactions=Files.Under(game,".JimJAmes_UPK/transactions");
  foreach(var c in spec.copies) { Validate(c.path,c.payload);Files.Require(c.size>=0 && ValidHash(c.sha256),"Invalid copy specification.");allowed.Add(c.path,c.sha256); }
  foreach(var p in AllPatches()) {
   Validate(p.path,p.payload);Files.Require(p.before_size>=0 && p.after_size>p.before_size && ValidHash(p.before_sha256) && ValidHash(p.after_sha256) && ValidHash(p.payload_sha256) && p.writes!=null,"Invalid patch specification.");
   long end=-1;foreach(var w in p.writes.OrderBy(w=>w.offset)) {
    int len=Files.Bytes(w.before).Length;Files.Require(w.offset>=0 && w.offset>=end && len>0 && len==Files.Bytes(w.after).Length && w.offset+len<=p.before_size,"Invalid/overlapping patch range.");end=w.offset+len;
   }
   if(spec.patches.Contains(p))allowed.Add(p.path,p.after_sha256);
   else Files.Require(spec.patches.Any(x=>x.path==p.path),"Alternate patch has no current target.");
  }
 }
 System.Collections.Generic.IEnumerable<PatchItem> AllPatches() { return spec.patches.Concat(spec.legacy_patches??new List<PatchItem>()).Concat(spec.upgrade_patches??new List<PatchItem>()); }
 PatchItem PatchFor(Operation op) {
  var matches=AllPatches().Where(p=>p.path==op.path && p.before_sha256==op.before_sha256 && p.after_sha256==op.after_sha256 && p.before_size==op.before_size).ToList();
  Files.Require(matches.Count==1,"Unrecognized texture recovery operation.");return matches[0];
 }
 static bool ValidHash(string hash) { return hash!=null && hash.Length==64 && hash.All(c=>"0123456789abcdef".Contains(c)); }
 void Validate(string target,string payload) { Files.Under(game,target);Files.Under(package,payload); }
 void Cancel() { if(cancelled()) throw new OperationCanceledException("Installation cancelled; previous files restored."); }
 string Target(string relative) { return Files.Under(game,relative); }
 string Payload(string relative) { return Files.Under(package,relative); }
 string JournalPath(string tx) { return Files.Under(game,tx+"/journal.json"); }
 void Save(string tx,Journal journal) { Files.Save(JournalPath(tx),journal); }
 string NewTransaction() {
  long ticks=DateTime.UtcNow.Ticks;
  if(Directory.Exists(transactions)) foreach(string directory in Directory.GetDirectories(transactions)) {
   string name=Path.GetFileName(directory);long prior;DateTime legacy;
   if(name.Length>=35 && name[15]=='~' && Int64.TryParse(name.Substring(16,19),out prior)) ticks=Math.Max(ticks,checked(prior+1));
   else if(name.Length>=15 && DateTime.TryParseExact(name.Substring(0,15),"yyyyMMdd_HHmmss",System.Globalization.CultureInfo.InvariantCulture,System.Globalization.DateTimeStyles.AssumeUniversal|System.Globalization.DateTimeStyles.AdjustToUniversal,out legacy)) ticks=Math.Max(ticks,checked(legacy.Ticks+1));
  }
  // '~' sorts after the legacy '_' suffix in the same second; ticks make
  // consecutive updates monotonic even when the wall clock has low precision.
  return ".JimJAmes_UPK/transactions/"+new DateTime(ticks,DateTimeKind.Utc).ToString("yyyyMMdd_HHmmss",System.Globalization.CultureInfo.InvariantCulture)+"~"+ticks.ToString("D19",System.Globalization.CultureInfo.InvariantCulture)+"_"+Guid.NewGuid().ToString("N").Substring(0,8);
 }
 void ValidateJournal(Journal j) {
  Files.Require((j.release=="R509" || j.release=="R485" || j.release=="R483" || j.release=="R478" || j.release=="R472" || j.release=="R466" || j.release=="R464" || j.release=="R461") && j.operations!=null,"Unrecognized recovery journal.");
  foreach(var op in j.operations) {
   Files.Require(allowed.ContainsKey(op.path) && (op.after_sha256==allowed[op.path] || ((j.release=="R461" || j.release=="R464" || j.release=="R466" || j.release=="R472" || j.release=="R478" || j.release=="R483" || j.release=="R485") && ((spec.legacy_copies!=null && spec.legacy_copies.Any(c=>c.path==op.path && c.sha256==op.after_sha256)) || (spec.legacy_patches!=null && spec.legacy_patches.Any(p=>p.path==op.path && p.after_sha256==op.after_sha256))))) && (op.kind=="copy" || op.kind=="patch"),"Recovery journal does not match this release.");Target(op.path);
   if(op.kind=="patch") {
    var p=PatchFor(op);Files.Require(op.writes!=null && op.writes.Count==p.writes.Count,"Invalid patch recovery journal.");
    for(int i=0;i<p.writes.Count;i++) Files.Require(op.writes[i].offset==p.writes[i].offset && op.writes[i].before==p.writes[i].before && op.writes[i].after==p.writes[i].after,"Recovery bytes do not match this release.");
   }
  }
 }
 void CleanStage(string tx) {
  string stage=Files.Under(game,tx+"/stage");if(!Directory.Exists(stage)) return;
  RemoveStage(stage);
 }
 void RemoveStage(string directory) {
  // Check each child before descending; never follow a reparse point.
  foreach(string p in Directory.GetFileSystemEntries(directory)) {
   Files.Under(game,p.Substring(game.TrimEnd('\\').Length+1));
   if(Directory.Exists(p))RemoveStage(p);else File.Delete(p);
  }
  Directory.Delete(directory,false);
 }
 public void Recover() {
  guard();if(!Directory.Exists(transactions)) return;
  foreach(string directory in Directory.GetDirectories(transactions).OrderBy(x=>x,StringComparer.Ordinal)) {
   string tx=directory.Substring(game.TrimEnd('\\').Length+1);string path=JournalPath(tx);if(!File.Exists(path))continue;
   Journal j=Files.Read<Journal>(path);ValidateJournal(j);
   if(j.state=="committed" || j.state=="restored") continue;
   report("Restoring an interrupted installation...");Rollback(tx,j);
  }
 }
 void CopyVerified(string input,string output,string hash) {
  Directory.CreateDirectory(Path.GetDirectoryName(output));
  using(var src=File.OpenRead(input)) using(var dst=new FileStream(output,FileMode.CreateNew,FileAccess.Write,FileShare.None)) using(var h=SHA256.Create()) {
   byte[] b=new byte[4*1024*1024];int n;while((n=src.Read(b,0,b.Length))>0){Cancel();dst.Write(b,0,n);h.TransformBlock(b,0,n,b,0);}h.TransformFinalBlock(new byte[0],0,0);dst.Flush(true);Files.Require(Files.Hex(h.Hash)==hash,"Payload checksum mismatch: "+Path.GetFileName(input));
  }
 }
 static void ReadExactly(Stream f,byte[] bytes) { int done=0;while(done<bytes.Length){int n=f.Read(bytes,done,bytes.Length-done);if(n==0)throw new EndOfStreamException();done+=n;} }
 void ApplyPatch(PatchItem patch) {
  string target=Target(patch.path);Files.Require(Files.Hash(target)==patch.before_sha256,"File changed during preparation: "+patch.path);
  using(var f=new FileStream(target,FileMode.Open,FileAccess.ReadWrite,FileShare.None)) {
   Files.Require(f.Length==patch.before_size,"Unexpected texture file size.");
   foreach(var w in patch.writes) { byte[] old=new byte[Files.Bytes(w.before).Length];f.Position=w.offset;ReadExactly(f,old);Files.Require(Files.Hex(old)==w.before,"Unexpected texture bytes."); }
   f.Position=patch.before_size;
   using(var src=File.OpenRead(Payload(patch.payload))) { byte[] b=new byte[4*1024*1024];int n;while((n=src.Read(b,0,b.Length))>0){Cancel();f.Write(b,0,n);} }
   f.Flush(true);FaultAt("patch_append");Cancel();
   foreach(var w in patch.writes){f.Position=w.offset;byte[] data=Files.Bytes(w.after);f.Write(data,0,data.Length);}f.Flush(true);
  }
  Files.Require(new FileInfo(target).Length==patch.after_size && Files.Hash(target)==patch.after_sha256,"Texture verification failed: "+patch.path);
 }
 void Rollback(string tx,Journal j) {
  guard();ValidateJournal(j);j.state="restoring";Save(tx,j);
  foreach(var op in j.operations.AsEnumerable().Reverse()) {
   if(op.phase=="planned" || op.phase=="restored")continue;
   string target=Target(op.path);report("Restoring "+Path.GetFileName(op.path));
   if(op.kind=="patch") {
    PatchItem patch=PatchFor(op);
    Files.Require(new FileInfo(target).Length<=patch.after_size && VirtualOriginalHash(target,op.before_size,op.writes)==op.before_sha256,"Texture data changed outside the installer; restoration stopped: "+op.path);
    using(var f=new FileStream(target,FileMode.Open,FileAccess.ReadWrite,FileShare.None)) {
     Files.Require(f.Length>=op.before_size,"Texture file was truncated outside the installer.");
     foreach(var w in op.writes){byte[] b=Files.Bytes(w.before);f.Position=w.offset;f.Write(b,0,b.Length);}f.SetLength(op.before_size);f.Flush(true);
    }
    Files.Require(Files.Hash(target)==op.before_sha256,"Texture restoration failed: "+op.path);
   } else {
    string backup=Files.Under(game,tx+"/backup/"+op.path);
    if(op.existed) {
     if(File.Exists(backup)) {
      Files.Require(Files.Hash(backup)==op.before_sha256,"Rollback copy changed: "+op.path);
      if(File.Exists(target)){string h=Files.Hash(target);Files.Require(h==op.after_sha256 || h==op.before_sha256,"A file changed outside the installer; restoration stopped: "+op.path);}
      if(File.Exists(target))File.Delete(target);Directory.CreateDirectory(Path.GetDirectoryName(target));File.Move(backup,target);
     }
     Files.Require(File.Exists(target) && Files.Hash(target)==op.before_sha256,"Original file cannot be restored: "+op.path);
    } else if(File.Exists(target)) { Files.Require(Files.Hash(target)==op.after_sha256,"Refusing to remove a file modified outside the installer: "+op.path);File.Delete(target); }
   }
   op.phase="restored";Save(tx,j);
  }
  j.state="restored";Save(tx,j);CleanStage(tx);
 }
 public static string VirtualOriginalHash(string path,long length,List<WriteItem> writes) {
  using(var f=File.OpenRead(path)) using(var h=SHA256.Create()) {
   Files.Require(f.Length>=length,"Texture file was truncated outside the installer.");byte[] b=new byte[4*1024*1024];long at=0;
   while(at<length) {
    int n=(int)Math.Min(b.Length,length-at),done=0;while(done<n){int r=f.Read(b,done,n-done);if(r==0)throw new EndOfStreamException();done+=r;}
    foreach(var w in writes){byte[] before=Files.Bytes(w.before);long lo=Math.Max(at,w.offset),hi=Math.Min(at+n,w.offset+before.Length);if(lo<hi)Buffer.BlockCopy(before,(int)(lo-w.offset),b,(int)(lo-at),(int)(hi-lo));}
    h.TransformBlock(b,0,n,b,0);at+=n;
   }
   h.TransformFinalBlock(new byte[0],0,0);return Files.Hex(h.Hash);
  }
 }
 public string Install() {
  Files.SupportedExe(game);guard();Recover();Cancel();List<Operation> ops=new List<Operation>();long required=128*1024*1024;
  foreach(var c in spec.copies) {
   Cancel();report("Checking "+Path.GetFileName(c.path));string src=Payload(c.payload);Files.Require(File.Exists(src) && new FileInfo(src).Length==c.size,"Missing/wrong package file: "+c.payload);
   string target=Target(c.path);bool exists=File.Exists(target);string before=exists?Files.Hash(target):null;if(before==c.sha256)continue;
   ops.Add(new Operation {path=c.path,kind="copy",phase="planned",existed=exists,before_sha256=before,after_sha256=c.sha256});required+=c.size;
  }
  foreach(var p in spec.patches) {
   Cancel();report("Checking "+Path.GetFileName(p.path));string src=Payload(p.payload);Files.Require(File.Exists(src) && new FileInfo(src).Length==p.after_size-p.before_size && Files.Hash(src)==p.payload_sha256,"Missing/damaged texture patch: "+p.path);
   string target=Target(p.path);Files.Require(File.Exists(target),"Missing original texture file: "+p.path+". Verify game files in Steam first.");string h=Files.Hash(target);if(h==p.after_sha256)continue;
   PatchItem chosen=p;
   if(new FileInfo(target).Length!=p.before_size || h!=p.before_sha256) {
    chosen=(spec.upgrade_patches??new List<PatchItem>()).SingleOrDefault(x=>x.path==p.path && x.before_sha256==h && x.before_size==new FileInfo(target).Length && x.after_sha256==p.after_sha256);
    Files.Require(chosen!=null,"Unsupported/modified original texture file: "+p.path+". No installation changes were made. Restore that file through Steam, then retry.");
    string upgrade=Payload(chosen.payload);Files.Require(File.Exists(upgrade) && new FileInfo(upgrade).Length==chosen.after_size-chosen.before_size && Files.Hash(upgrade)==chosen.payload_sha256,"Missing/damaged upgrade texture patch: "+p.path);
   }
   ops.Add(new Operation {path=chosen.path,kind="patch",phase="planned",existed=true,before_sha256=chosen.before_sha256,after_sha256=chosen.after_sha256,before_size=chosen.before_size,writes=chosen.writes});required+=chosen.after_size-chosen.before_size;
  }
  if(ops.Count==0)return "R509 is already installed. All target files match.";
  Files.Require(new DriveInfo(Path.GetPathRoot(game)).AvailableFreeSpace>=required,"Not enough free space to stage the installation and keep rollback files.");
  string tx=NewTransaction();Journal j=new Journal{release="R509",state="staging",operations=ops};Save(tx,j);
  try {
   foreach(var op in ops.Where(x=>x.kind=="copy")) {
    report("Preparing "+Path.GetFileName(op.path));CopyItem c=spec.copies.Single(x=>x.path==op.path);CopyVerified(Payload(c.payload),Files.Under(game,tx+"/stage/"+op.path),c.sha256);
   }
   guard();Cancel();j.state="installing";Save(tx,j);
   foreach(var op in ops) {
    guard();Cancel();report("Installing "+Path.GetFileName(op.path));string target=Target(op.path);
    if(op.kind=="copy") {
     Files.Require(op.existed ? File.Exists(target)&&Files.Hash(target)==op.before_sha256 : !File.Exists(target),"A game file changed during preparation: "+op.path);
     op.phase="started";Save(tx,j);string backup=Files.Under(game,tx+"/backup/"+op.path);
     Directory.CreateDirectory(Path.GetDirectoryName(target));
     if(op.existed){Directory.CreateDirectory(Path.GetDirectoryName(backup));File.Move(target,backup);}FaultAt("copy_backed_up");
     File.Move(Files.Under(game,tx+"/stage/"+op.path),target);Files.Require(Files.Hash(target)==op.after_sha256,"Installed file verification failed: "+op.path);
    } else {op.phase="started";Save(tx,j);ApplyPatch(PatchFor(op));}
    op.phase="done";Save(tx,j);FaultAt("operation_done");
   }
   j.state="committed";Save(tx,j);CleanStage(tx);return "R509 installed and verified. Previous files are kept for restoration.";
  } catch(Exception error) {
   try {Rollback(tx,j);}catch(Exception recovery){throw new IOException(error.Message+"\nAutomatic restoration needs attention: "+recovery.Message+"\nKeep "+JournalPath(tx),recovery);}throw;
  }
 }
 public string Uninstall() {
  Files.SupportedExe(game);guard();Recover();Files.Require(Directory.Exists(transactions),"No installer rollback was found. A manually installed mod must be removed through your own backups or Steam verification.");
  foreach(string directory in Directory.GetDirectories(transactions).OrderByDescending(x=>x,StringComparer.Ordinal)) {
   string tx=directory.Substring(game.TrimEnd('\\').Length+1);string path=JournalPath(tx);if(!File.Exists(path))continue;
   Journal j=Files.Read<Journal>(path);ValidateJournal(j);if(j.state!="committed")continue;
   foreach(var op in j.operations){Cancel();Files.Require(File.Exists(Target(op.path)) && Files.Hash(Target(op.path))==op.after_sha256,"A file was modified after installation: "+op.path+". Automatic restoration stopped to preserve that change.");}
   guard();Rollback(tx,j);return "Previous files restored and verified.";
  }
  return "There is no active installer transaction to restore.";
 }
}
}
