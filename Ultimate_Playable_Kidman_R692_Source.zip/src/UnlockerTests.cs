using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using JimJAmes.UPK;

class UnlockerTests {
 static string Root,Components;
 static void Check(bool x,string message){if(!x)throw new Exception(message);}
 static Fixture New(string name){var f=new Fixture(Path.Combine(Root,name));File.Copy(Path.Combine(Components,"Optional/FightingChance/steam_api64_o.dll"),Path.Combine(f.Game,"steam_api64.dll"));return f;}
 static Engine Enabled(Fixture f){return new Engine(f.Package,f.Game,f.Spec,s=>{},()=>false,()=>{},true,Components);}
 static void OriginalApi(Fixture f){Check(Files.Hash(Path.Combine(f.Game,"steam_api64.dll"))==FightingChance.OriginalHash,"Native API not restored");Check(!File.Exists(Path.Combine(f.Game,"steam_api64_o.dll")),"New companion not removed");}
 static void Fail(Action action){bool threw=false;try{action();}catch{threw=true;}Check(threw,"Expected rejection");}
 public static int Main(string[] args) {
  try {
   Root=Path.GetFullPath(args[0]);Components=Path.GetFullPath(args[1]);Directory.CreateDirectory(Root);
   var f=New("default_off");f.Engine().Install();OriginalApi(f);f.Engine().Uninstall();f.Original();Console.WriteLine("PASS option off preserves Steam API");
   f=New("install_restore");Enabled(f).Install();Check(Files.Hash(Path.Combine(f.Game,"steam_api64.dll"))==FightingChance.ProxyHash,"Proxy missing");Check(Files.Hash(Path.Combine(f.Game,"steam_api64_o.dll"))==FightingChance.OriginalHash,"Companion missing");int count=Directory.GetDirectories(Path.Combine(f.Game,".JimJAmes_UPK/transactions")).Length;Enabled(f).Install();Check(Directory.GetDirectories(Path.Combine(f.Game,".JimJAmes_UPK/transactions")).Length==count,"Idempotence created a journal");f.Engine().Uninstall();f.Original();OriginalApi(f);Console.WriteLine("PASS option install, idempotence, restore with checkbox off");
   f=New("unknown_proxy");File.WriteAllBytes(Path.Combine(f.Game,"steam_api64.dll"),new byte[500]);Fail(()=>Enabled(f).Install());Check(new FileInfo(Path.Combine(f.Game,"steam_api64.dll")).Length==500,"Unknown proxy overwritten");f.Original();Console.WriteLine("PASS unknown Steam proxy refused without game changes");
   f=New("modified_companion");File.WriteAllBytes(Path.Combine(f.Game,"steam_api64_o.dll"),new byte[100]);Fail(()=>Enabled(f).Install());Check(new FileInfo(Path.Combine(f.Game,"steam_api64_o.dll")).Length==100,"Unknown companion overwritten");Console.WriteLine("PASS unknown companion preserved");
   f=New("rollback_option");int operations=0;Engine.Fault=point=>{if(point=="operation_done" && ++operations==4)throw new IOException("Injected failure after companion install");};try{Fail(()=>Enabled(f).Install());}finally{Engine.Fault=null;}f.Original();OriginalApi(f);Console.WriteLine("PASS failed optional install rolls back campaign and DLLs");
   f=New("standalone");f.Engine().Install();var spec=new Specification{release="R692",copies=new List<CopyItem>(),patches=new List<PatchItem>()};var only=new Engine(Components,f.Game,spec,s=>{},()=>false,()=>{},true,Components,true);only.Install();f.Installed();new Engine(Components,f.Game,spec,s=>{},()=>false,()=>{},false,Components,true).Uninstall();OriginalApi(f);f.Installed();f.Engine().Uninstall();f.Original();Console.WriteLine("PASS standalone option transaction preserves existing campaign journal");
   f=New("later_edit");Enabled(f).Install();File.WriteAllBytes(Path.Combine(f.Game,"steam_api64.dll"),new byte[900]);Fail(()=>f.Engine().Uninstall());Check(new FileInfo(Path.Combine(f.Game,"steam_api64.dll")).Length==900,"Later edit not preserved");Console.WriteLine("PASS later Steam API edits block restore");
   Console.WriteLine("ALL OPTIONAL TESTS PASSED");return 0;
  }catch(Exception e){Console.WriteLine(e);return 1;}
 }
}
